function t(i){if(i)throw i}export{t as b};
