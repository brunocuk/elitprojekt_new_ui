function n(i){return i.join(" ").trim()}export{n as s};
